# Lecture Walkthrough: JavaFX Event Handling with SceneBuilder

## Lecture Goal

By the end of this lecture, students should understand that:

```text
FXML file = GUI structure created in SceneBuilder
Controller class = Java code that handles events
fx:id = connects a GUI control to a Java variable
onAction = connects a GUI event to a Java method
```

## Before Starting

Students should already know:

- What `Application`, `Stage`, and `Scene` are
- How to load a basic FXML screen
- How to create layouts and controls in SceneBuilder
- How to modify simple properties in SceneBuilder

## Part 1: Open the FXML in SceneBuilder

Open:

```text
src/com/oop/gui/event-demo.fxml
```

Show the root layout:

```text
AnchorPane
└── VBox
    ├── Label title
    ├── Label instruction
    ├── GridPane form
    ├── HBox buttons
    ├── Label messageLabel
    └── TextArea outputArea
```

Teaching point:

```text
The GUI is created visually. We are not creating controls programmatically.
```

## Part 2: Explain fx:controller

Click the root `AnchorPane` in SceneBuilder.

In the Controller section, show:

```text
Controller class: com.oop.gui.EventDemoController
```

Explain:

```text
This tells JavaFX which Java class will control this FXML screen.
```

## Part 3: Explain fx:id

Click each control and show its fx:id.

| GUI Control | fx:id |
|---|---|
| Name TextField | `nameField` |
| Roll No TextField | `rollNoField` |
| Department ComboBox | `departmentComboBox` |
| Morning RadioButton | `morningRadioButton` |
| Evening RadioButton | `eveningRadioButton` |
| Library CheckBox | `libraryCheckBox` |
| Sports CheckBox | `sportsCheckBox` |
| Message Label | `messageLabel` |
| Output TextArea | `outputArea` |
| Submit Button | `submitButton` |
| Clear Button | `clearButton` |

Then open `EventDemoController.java` and show the matching fields:

```java
@FXML
private TextField nameField;
```

Teaching point:

```text
The fx:id in SceneBuilder must match the variable name in the controller.
```

## Part 4: Explain onAction

In SceneBuilder, click the Submit button.

Go to Code section and show:

```text
On Action: #handleSubmit
```

Then open the controller and show:

```java
@FXML
private void handleSubmit() {
    ...
}
```

Teaching point:

```text
The onAction value in SceneBuilder must match a method in the controller.
```

## Part 5: Run the Demo

Run:

```text
MainApp.java
```

Demonstrate:

1. Click Submit with empty form.
2. Show error message and Alert.
3. Enter name and press Enter.
4. Select a different department.
5. Select Library/Sports.
6. Click Submit.
7. Click Clear.

## Part 6: Small In-Class Activity

Ask students to add one new field in SceneBuilder:

```text
Email TextField
```

Then ask them to:

1. Give it `fx:id="emailField"`.
2. Add this field in `EventDemoController.java`:

```java
@FXML
private TextField emailField;
```

3. Read it inside `handleSubmit()`:

```java
String email = emailField.getText().trim();
```

4. Display it in the output area.

## Part 7: Common Student Mistakes

### Mistake 1: fx:id spelling mismatch

FXML:

```text
nameField
```

Controller:

```java
private TextField studentNameField;
```

This will not connect.

### Mistake 2: Method name mismatch

FXML:

```text
onAction="#handleSubmit"
```

Controller:

```java
private void submitButtonClicked() { }
```

This will not work unless the names match.

### Mistake 3: Missing @FXML

If a field or private method is used by FXML, write `@FXML` above it.

### Mistake 4: Wrong controller class name

The controller class written in SceneBuilder must include the full package name:

```text
com.oop.gui.EventDemoController
```

## Recommended Homework

Create a simple calculator screen in SceneBuilder with:

- Two TextFields
- Four Buttons: Add, Subtract, Multiply, Divide
- One Label or TextArea for result

Each button should call a different event handler method in the controller.
