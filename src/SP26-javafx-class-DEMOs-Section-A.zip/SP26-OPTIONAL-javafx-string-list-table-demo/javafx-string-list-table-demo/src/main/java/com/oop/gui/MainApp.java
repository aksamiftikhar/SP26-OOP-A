package com.oop.gui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader fxmlLoader =
                new FXMLLoader(MainApp.class.getResource("string-list-table-demo.fxml"));

        Scene scene = new Scene(fxmlLoader.load(), 720, 430);

        stage.setTitle("String ListView and TableView Demo");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
