module com.example.demo_fa25_bse_a {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.demo_fa25_bse_a to javafx.fxml;
    exports com.example.demo_fa25_bse_a;
}