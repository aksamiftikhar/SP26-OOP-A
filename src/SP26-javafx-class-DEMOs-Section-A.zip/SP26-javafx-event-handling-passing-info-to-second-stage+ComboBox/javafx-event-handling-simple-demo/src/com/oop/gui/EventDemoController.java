package com.oop.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;

import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * Controller class for event-demo.fxml.
 *
 * Teaching focus:
 * - @FXML fields connect to fx:id values in SceneBuilder.
 * - @FXML methods connect to onAction values in SceneBuilder.
 * - The controller reads input from controls and updates other controls.
 */
public class EventDemoController {

    // These names must match the fx:id values in event-demo.fxml / SceneBuilder.
    @FXML
    private TextField nameField;

    @FXML
    private TextField rollNoField;

    @FXML
    private ComboBox<String> departmentComboBox;

    @FXML
    private RadioButton morningRadioButton;

    @FXML
    private RadioButton eveningRadioButton;

    @FXML
    private CheckBox libraryCheckBox;

    @FXML
    private CheckBox sportsCheckBox;

    @FXML
    private Label messageLabel;

    @FXML
    private TextArea outputArea;

    @FXML
    private Button submitButton;

    @FXML
    private Button clearButton;

    private ToggleGroup shiftGroup;


    /**
     * initialize() is called automatically after the FXML file is loaded.
     * Use it for initial setup of controls.
     */

    @FXML
    private void initialize() {

        departmentComboBox.getItems().addAll(
                "Computer Science",
                "Software Engineering",
                "Artificial Intelligence",
                "Data Science"
        );

        // Select item using Selection Manager of ComboBox
        departmentComboBox.getSelectionModel().select(0);
//
        shiftGroup = new ToggleGroup();
        morningRadioButton.setToggleGroup(shiftGroup);
        eveningRadioButton.setToggleGroup(shiftGroup);
        morningRadioButton.setSelected(true);
//
        messageLabel.setText("Enter student information and click Submit.");
        outputArea.setText("Output will be shown here.");
    }

    /**
     * Connected with Submit button's onAction property.
     */
    @FXML
    private void handleSubmit(ActionEvent ae) throws IOException {
        String name = nameField.getText();
        String department = departmentComboBox.getValue();
        String facilities = getSelectedFacilities();

        if (name.isEmpty()) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Validation Error");
            alert.setHeaderText("Name Required");
            alert.setContentText("Please enter your name before submitting.");
            alert.showAndWait();
            return;
        }

        if (department == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Validation Error");
            alert.setHeaderText("Department Required");
            alert.setContentText("Please select a department before submitting.");
            alert.showAndWait();
            return;
        }

        FXMLLoader fxmlLoader = new FXMLLoader(MainApp.class.getResource("result-screen.fxml"));

        Scene scene = new Scene(fxmlLoader.load(), 600, 420);
//
        ResultController controller = fxmlLoader.getController();
        controller.setUserData(name, department, facilities);

        Stage stage = (Stage) nameField.getScene().getWindow();

        stage.setScene(scene);
        stage.show();
    }
//    @FXML
//    private void handleSubmit() {
//        String name = nameField.getText().trim();
//        String rollNo = rollNoField.getText().trim();
//        String department = departmentComboBox.getValue();
//        String shift = getSelectedShift();
//        String facilities = getSelectedFacilities();
//
//        if (name.isEmpty()) {
//            showError("Name is required.");
//            nameField.requestFocus();
//            return;
//        }
//
//        if (rollNo.isEmpty()) {
//            showError("Roll number is required.");
//            rollNoField.requestFocus();
//            return;
//        }
//
//        messageLabel.setText("Student information submitted successfully.");
//
//        outputArea.setText(
//                "Submitted Student Information\n" +
//                "-----------------------------\n" +
//                "Name: " + name + "\n" +
//                "Roll No: " + rollNo + "\n" +
//                "Department: " + department + "\n" +
//                "Shift: " + shift + "\n" +
//                "Facilities: " + facilities
//        );
//    }

    /**
     * Connected with Clear button's onAction property.
     */
    @FXML
    private void handleClear() {
        nameField.clear();
        rollNoField.clear();
        departmentComboBox.getSelectionModel().selectFirst();
        morningRadioButton.setSelected(true);
        libraryCheckBox.setSelected(false);
        sportsCheckBox.setSelected(false);

        messageLabel.setText("Form cleared. Enter new information.");
        outputArea.setText("Output will be shown here.");
        nameField.requestFocus();
    }

    /**
     * Connected with nameField's onAction property.
     * This event runs when the user presses Enter inside the name TextField.
     */
    @FXML
    private void handleNameEntered() {
        messageLabel.setText("Name entered: " + nameField.getText().trim());
        rollNoField.requestFocus();
    }

    /**
     * Connected with departmentComboBox's onAction property.
     */
    @FXML
    private void handleDepartmentChanged() {
        messageLabel.setText("Selected department: " + departmentComboBox.getValue());
    }

    /**
     * Connected with both CheckBoxes' onAction property.
     */
    @FXML
    private void handleFacilityChanged() {

        messageLabel.setText("Facilities selected: " + getSelectedFacilities());
    }

    private String getSelectedShift() {
        if (morningRadioButton.isSelected()) {
            return "Morning";
        }
        return "Evening";
    }

    private String getSelectedFacilities() {
        String facilities = "";

        if (libraryCheckBox.isSelected()) {
            facilities += "Library ";
        }

        if (sportsCheckBox.isSelected()) {
            facilities += "Sports ";
        }

        if (facilities.isBlank()) {
            return "None";
        }

        return facilities.trim();
    }

    private void showError(String message) {
        messageLabel.setText(message);

        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Input Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
