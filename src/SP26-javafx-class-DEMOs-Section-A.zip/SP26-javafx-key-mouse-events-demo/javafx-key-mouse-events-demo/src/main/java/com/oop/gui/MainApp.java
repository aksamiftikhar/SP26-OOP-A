package com.oop.gui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        FXMLLoader fxmlLoader =
                new FXMLLoader(MainApp.class.getResource("key-mouse-events-demo.fxml"));

        Scene scene = new Scene(fxmlLoader.load(), 850, 560);

        stage.setTitle("JavaFX KeyEvent and MouseEvent Demo");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}
