package com.example.demo_javafx_event_sp26;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloController {
    @FXML
    private Label welcomeText;

    @FXML
    private TextField txtUserName;

    @FXML
    private TextField txtPassword;

    @FXML
    private Button btnLogin;

    @FXML
    private Button btnInfo;

    @FXML
    private Button btnExit;

    @FXML
    private CheckBox cbxMath;

    @FXML
    private CheckBox cbxPhysics;



    @FXML
    protected void onLoginClick() {
//        welcomeText.setText("Welcome to JavaFx Event");
//        txtUserName.setText("Welcome");

        if(txtUserName.getText().isEmpty() || txtPassword.getText().isEmpty()){
            Alert alert = new Alert(Alert.AlertType.ERROR);


            alert.setTitle("Warning");
            alert.setHeaderText("kuch na kuch");
            alert.setContentText("Please fill all the fields");

            alert.showAndWait();
            return;
        }
        if(txtUserName.getText().equals("admin") && txtPassword.getText().equals("admin")){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Welcome");
            alert.setHeaderText(null);
            alert.setContentText("You are successfully logged in");
            alert.showAndWait();
            welcomeText.setText("Welcome " + txtUserName.getText());
        }
    }

    @FXML
    public void UserNameEntered()
    {
        welcomeText.setText("Welcome " + txtUserName.getText());
        txtPassword.requestFocus();
    }

    @FXML
    public void SubjectChanged()
    {
        if(cbxMath.isSelected() == true)
            System.out.println("Math");
        else if (cbxPhysics.isSelected() == true)
            System.out.println("Physics");
    }
    @FXML
    protected void showInfoScreen() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("info_screen.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        Stage stage = new Stage();
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();    }
}
