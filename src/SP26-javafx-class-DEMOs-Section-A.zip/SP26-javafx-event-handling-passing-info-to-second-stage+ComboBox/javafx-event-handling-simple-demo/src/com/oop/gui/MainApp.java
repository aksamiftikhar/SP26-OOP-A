package com.oop.gui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Main application class.
 *
 * This version is intentionally simple for teaching:
 * 1. It loads only one FXML screen.
 * 2. The GUI is designed in SceneBuilder.
 * 3. All button/control behavior is written in EventDemoController.
 *
 * In IntelliJ IDEA, open this file and run the main() method.
 */
public class MainApp {

    public static void main(String[] args) {
        Application.launch(SimpleEventApp.class, args);
    }

    public static class SimpleEventApp extends Application {
        @Override
        public void start(Stage stage) throws IOException {
            FXMLLoader fxmlLoader = new FXMLLoader(MainApp.class.getResource("event-demo.fxml"));

            Scene scene = new Scene(fxmlLoader.load(), 600, 420);

            stage.setTitle("JavaFX Event Handling Demo");
            stage.setScene(scene);
            stage.show();
        }
    }
}
