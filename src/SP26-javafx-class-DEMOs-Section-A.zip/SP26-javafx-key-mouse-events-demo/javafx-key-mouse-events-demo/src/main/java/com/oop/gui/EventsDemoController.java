package com.oop.gui;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;

public class EventsDemoController {

    @FXML
    private TextField keyInputField;

    @FXML
    private Label keyStatusLabel;

    @FXML
    private StackPane mouseArea;

    @FXML
    private Label mouseStatusLabel;

    @FXML
    private Label mousePositionLabel;

    @FXML
    private TextArea logTextArea;

    @FXML
    public void initialize() {
        log("Demo started.");
        log("Type in the text field to generate KeyEvent.");
        log("Move/click/drag inside the mouse area to generate MouseEvent.");
        log("Keyboard shortcut: Ctrl + L clears the log.");
    }

    // ============================================================
    // KeyEvent handlers
    // Connected from FXML/SceneBuilder:
    // onKeyPressed, onKeyTyped, onKeyReleased
    // ============================================================

    // Event <- ActionEvent, KeyEvent, MouseEvent

    @FXML
    private void handleKeyPressed(KeyEvent event) {
        KeyCode code = event.getCode();
        keyStatusLabel.setText(
                "Key Pressed: code=" + code
                        + ", text=" + event.getText()
                        + ", ctrl=" + event.isControlDown()
                        + ", shift=" + event.isShiftDown()
                        + ", alt=" + event.isAltDown()
        );


        // Demonstrate special keys.
        if (code == KeyCode.ENTER) {
            log("ENTER pressed. Current text: " + keyInputField.getText());
        } else if (code == KeyCode.ESCAPE) {
            keyInputField.clear();
            log("ESCAPE pressed. Text field cleared.");
        } else if (event.isControlDown() && code == KeyCode.L) {
            logTextArea.clear();
            log("Log cleared using Ctrl + L.");
        } else if (code == KeyCode.UP || code == KeyCode.DOWN
                || code == KeyCode.LEFT || code == KeyCode.RIGHT) {
            log("Arrow key pressed: " + code);
        }
    }

    @FXML
    private void handleKeyTyped(KeyEvent event) {
        // KEY_TYPED is useful for actual printable characters.
        // For special keys such as ENTER, ESC, arrow keys, use KEY_PRESSED.
        String character = event.getCharacter();

        if (!character.trim().isEmpty()) {
            log("Key typed character: " + character);
        }
    }

    @FXML
    private void handleKeyReleased(KeyEvent event) {
        keyStatusLabel.setText(
                "Key Released: " + event.getCode()
                        + " | Current text: " + keyInputField.getText()
        );
    }


    // ============================================================
    // MouseEvent handlers
    // Connected from FXML/SceneBuilder:
    // onMouseEntered, onMouseExited, onMouseMoved,
    // onMousePressed, onMouseDragged, onMouseReleased, onMouseClicked
    // ============================================================

    @FXML
    private void handleMouseEntered(MouseEvent event) {
        mouseStatusLabel.setText("Mouse entered the area.");
        mouseArea.setStyle("-fx-background-color: #e8f4ff; -fx-border-color: #2471a3; -fx-border-width: 2;");
        log("Mouse entered.");
    }

    @FXML
    private void handleMouseExited(MouseEvent event) {
        mouseStatusLabel.setText("Mouse exited the area.");
        mousePositionLabel.setText("Mouse Position: outside area");
        mouseArea.setStyle("-fx-background-color: #f5f5f5; -fx-border-color: #999999; -fx-border-width: 2;");
        log("Mouse exited.");
    }

    @FXML
    private void handleMouseMoved(MouseEvent event) {
        mousePositionLabel.setText(
                "Mouse Position: x=" + format(event.getX())
                        + ", y=" + format(event.getY())
        );
    }

    @FXML
    private void handleMousePressed(MouseEvent event) {
        mouseStatusLabel.setText(
                "Mouse pressed: button=" + event.getButton()
                        + ", x=" + format(event.getX())
                        + ", y=" + format(event.getY())
        );

        if(event.getButton() == MouseButton.PRIMARY) {

        }
        else if(event.getButton() == MouseButton.SECONDARY) {

        }

        log("Mouse pressed. Button=" + event.getButton()
                + ", PrimaryDown=" + event.isPrimaryButtonDown());
    }

    @FXML
    private void handleMouseDragged(MouseEvent event) {
        mouseStatusLabel.setText(
                "Mouse dragging at x=" + format(event.getX())
                        + ", y=" + format(event.getY())
        );

        mousePositionLabel.setText(
                "Drag Position: x=" + format(event.getX())
                        + ", y=" + format(event.getY())
        );
    }

    @FXML
    private void handleMouseReleased(MouseEvent event) {
        mouseStatusLabel.setText(
                "Mouse released: button=" + event.getButton()
                        + ", x=" + format(event.getX())
                        + ", y=" + format(event.getY())
        );

        log("Mouse released. Button=" + event.getButton());
    }

    @FXML
    private void handleMouseClicked(MouseEvent event) {
        mouseStatusLabel.setText(
                "Mouse clicked: button=" + event.getButton()
                        + ", clickCount=" + event.getClickCount()
        );

        if (event.getClickCount() == 2) {
            log("Double click detected.");
        } else {
            log("Mouse clicked. Button=" + event.getButton()
                    + ", clickCount=" + event.getClickCount());
        }
        if(event.getButton() == MouseButton.PRIMARY) {

        }
        else if(event.getButton() == MouseButton.SECONDARY) {

        }
    }


    // ============================================================
    // Helper methods
    // ============================================================

    private void log(String message) {
        logTextArea.appendText(message + "\n");
    }

    private String format(double value) {
        return String.format("%.1f", value);
    }
}
