package com.oop.gui;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Optional;

public class ResultController {

    @FXML
    private Label nameLabel;

    @FXML
    private Label departmentLabel;

    @FXML
    private Label statusLabel;

    @FXML
    private TextArea summaryArea;

    public void setUserData(String name, String department, String facilities) {
        nameLabel.setText(name);
        departmentLabel.setText(department);
        statusLabel.setText(facilities);

        summaryArea.setText(
                "Submitted Data\n" +
                        "-------------------------\n" +
                        "Name: " + name + "\n" +
                        "Department: " + department + "\n" +
                        "Facilities: " + facilities
        );
    }

    @FXML
    private void handleInformationDialog() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information Dialog");
        alert.setHeaderText("Information");
        alert.setContentText("This is an information message for the user.");
        alert.showAndWait();
    }

    @FXML
    private void handleWarningDialog() {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Warning Dialog");
        alert.setHeaderText("Warning");
        alert.setContentText("This dialog is used to warn the user about something.");
        alert.showAndWait();
    }

    @FXML
    private void handleErrorDialog() {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error Dialog");
        alert.setHeaderText("Error");
        alert.setContentText("This dialog is used to show an error message.");
        alert.showAndWait();
    }

    @FXML
    private void handleConfirmationDialog() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmation Dialog");
        alert.setHeaderText("Please Confirm");
        alert.setContentText("Do you want to continue?");

        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            summaryArea.appendText("\n\nUser clicked OK in confirmation dialog.");
        } else {
            summaryArea.appendText("\n\nUser cancelled the confirmation dialog.");
        }
    }

    @FXML
    private void handleBack() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainApp.class.getResource("event-demo.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 600, 420);
        
        Stage stage = (Stage) nameLabel.getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }
}